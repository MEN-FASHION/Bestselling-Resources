/* ============================================================
 * 趋势专区前台逻辑：登录校验 + 类目/月度/周度筛选 + 趋势文件列表 + 受控PDF预览 + 防下载
 * ============================================================ */
(function () {
  const $ = (sel) => document.querySelector(sel);

  let curTag = "全部";
  let curCat = "全部";
  let authMode = "register"; // 登录页模式：默认注册页面 register 注册 / login 登录
  let trends = [];
  let shownCats = [];
  // PDF 自绘预览状态
  let pdfDoc = null, pdfPage = 1, pdfScale = 1.0, pdfRendering = false;
  /* 预览状态：按 path 缓存已解析的文档，二次打开秒开；页面按需渲染，不一次性全画 */
  let pdfPath = "", pdfBaseScale = 1, pdfPages = [], pdfObserver = null, pdfLoadTask = null;
  const pdfCache = new Map();       /* path -> { doc, buf } */
  const PDF_CACHE_MAX = 3;          /* 最多留 3 份，避免占内存 */
  let recruitTasks = [];   // 招品任务清单
  let recruitSubs = [];    // 全部提交（前台悬浮显示用）
  let recruitCurUid = "";  // 当前登录商家 ID（前台只看自己的提交）
  let recruitCats = [];    // 招品专区类目（独立于趋势类目）
  let recruitCat = "全部"; // 招品当前选中类目
  let bestsellerTasks = [];   // BESTSELLER 任务清单
  let bestsellerSubs = [];    // 全部提交
  let bestsellerCurUid = "";  // 当前登录商家 ID
  let bestsellerCats = [];    // BESTSELLER 专区类目
  let bestsellerCat = "全部"; // BESTSELLER 当前选中类目
  let catVisibility = {};    // 各专区各类目是否前台可见
  let zoneVis = {};          // 各专区本身是否前台可见
  let zoneVisLoaded = false; // 专区可见性是否已加载
  let myZones = null;        // 当前登录用户级可见专区白名单（null/空 = 未配置，回退全局）
  // —— 分享预览（方案A）：管理员分享类目链接，未登录可浏览该类目缩略图 ——
  const shareQ = new URLSearchParams(location.search);
  const shareZone = shareQ.get("zone");
  const shareCat = (shareQ.get("cat") || "").trim();
  // 是否带分享类目目标（与登录态无关）：用于定位专区/类目
  const hasShareTarget = () => !!shareCat && (shareZone === "recruit" || shareZone === "bestseller");
  // 未登录时的分享预览模式：仅显示缩略图 + 登录引导
  const isSharePreview = () => !window.__loggedIn && hasShareTarget();

  // HTML转义（前台卡片信息区防注入）
  function escHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  // 提需时间只展示到日（截取 YYYY-MM-DD）
  function frontDay(v) {
    const s = String(v == null ? "" : v).trim();
    if (!s) return "";
    const m = s.match(/\d{4}[-/.年]\d{1,2}[-/.月]\d{1,2}/);
    if (m) return m[0].replace(/[年\/.]/g, "-").replace(/月/g, "-").replace(/-$/, "");
    return s;
  }

  Common.setToast(function (m, ok) { return toast(m, ok); }); // 接入公共模块
  function toast(msg, ok = true) {
    const t = document.getElementById("toast");
    if (!t) return;
    t.textContent = msg;
    t.style.background = ok ? "rgba(34,47,38,.92)" : "rgba(120,40,38,.92)";
    t.classList.add("show");
    clearTimeout(t._timer);
    t._timer = setTimeout(() => t.classList.remove("show"), 2600);
  }

  // 登录横幅：仅招品回品 / BESTSELLER 专区显示，趋势/视觉专区不显示
  function setBanner(visible) {
    const b = document.getElementById("login-banner");
    if (!b) return;
    b.classList.toggle("hidden", !visible || !!window.__loggedIn);
  }

  document.addEventListener("DOMContentLoaded", () => {
    $("#site-title").textContent = CONFIG.siteTitle || "TREND BANK";
    document.title = (CONFIG.siteTitle || "TREND BANK") + " · 趋势专区";
    if (window.pdfjsLib) {
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = "vendor/pdf.worker.min.js";
    }

    // 趋势专区始终需登录 —— 监听登录态
    SB.onAuth((session) => {
      window.__loggedIn = !!session;
      refreshUI();
      if (session && window.Common && Common.visit) Common.visit.track("trend");
    });
    // 访问统计（后台「数据看板」）：登记本次进入专区的访问与停留时长
    SB.getSession().then((s) => { if (s && window.Common && Common.visit) Common.visit.track("trend"); }).catch(() => {});
    // 兜底：异常情况下最多等3s后揭开遮罩
    setTimeout(hideSplash, 3000);

    $("#login-form").addEventListener("submit", onLogin);
    bindEmailSuggest();
    const authToggle = $("#auth-toggle-link");
    if (authToggle) authToggle.addEventListener("click", (e) => {
      e.preventDefault();
      authMode = authMode === "login" ? "register" : "login";
      applyAuthMode();
    });
    applyAuthMode(); // 初始渲染：默认注册界面
    $("#logout-btn").onclick = onLogout;
    // ---------- 修改密码（安全设置） ----------
    const pwdModal = document.getElementById("pwd-modal");
    if (pwdModal) {
      const openPwd = () => {
        const o = document.getElementById("pwd-old"), n = document.getElementById("pwd-new"), n2 = document.getElementById("pwd-new2");
        if (o) o.value = ""; if (n) n.value = ""; if (n2) n2.value = "";
        pwdModal.classList.remove("hidden");
        if (o) o.focus();
      };
      const closePwd = () => pwdModal.classList.add("hidden");
      const bp = document.getElementById("changepwd-btn");
      if (bp) bp.onclick = openPwd;
      const c1 = document.getElementById("pwd-cancel"); if (c1) c1.onclick = closePwd;
      const c2 = document.getElementById("pwd-close"); if (c2) c2.onclick = closePwd;
      pwdModal.addEventListener("click", (e) => { if (e.target === pwdModal) closePwd(); });
      const btn = document.getElementById("pwd-submit");
      if (btn) btn.onclick = async () => {
        const o = document.getElementById("pwd-old").value.trim();
        const n = document.getElementById("pwd-new").value;
        const n2 = document.getElementById("pwd-new2").value;
        if (!o) return toast("请输入旧密码", false);
        if (!n || n.length < 6) return toast("新密码至少6位", false);
        if (n !== n2) return toast("两次输入的新密码不一致", false);
        const r = await SB.changePassword(o, n);
        if (r.error) return toast(r.error.message || "修改失败", false);
        toast("密码修改成功", true);
        closePwd();
      };
    }
    // 登入横幅"立即登录"→ 进入登录页
    const lbGoto = document.getElementById("lb-goto");
    if (lbGoto) lbGoto.addEventListener("click", (e) => { e.preventDefault(); showLogin(); });
    $("#pdf-close").onclick = closePdf;
    $("#pdf-zoom-out").onclick = () => setPdfZoom(pdfScale - 0.15);
    $("#pdf-zoom-in").onclick = () => setPdfZoom(pdfScale + 0.15);
    $("#pdf-fit").onclick = () => { pdfScale = 1.0; relayoutPdf(); };
    $("#pdf-full").onclick = togglePdfFull;

    /* 全屏进出、窗口缩放后容器宽度变了，页宽要跟着重算 */
    let pdfResizeTimer = 0;
    const onPdfResize = () => {
      if (!pdfDoc) return;
      clearTimeout(pdfResizeTimer);
      pdfResizeTimer = setTimeout(() => { relayoutPdf(); }, 160);
    };
    window.addEventListener("resize", onPdfResize);
    document.addEventListener("fullscreenchange", () => {
      const btn = $("#pdf-full");
      if (btn) btn.textContent = document.fullscreenElement ? "退出全屏" : "全屏";
      onPdfResize();
    });
    $("#pdf-modal").addEventListener("click", (e) => { if (e.target.id === "pdf-modal") closePdf(); });
    window.addEventListener("keydown", (e) => {
      const m = $("#pdf-modal");
      if (m && !m.classList.contains("hidden")) {
        if (e.key === "Escape") closePdf();
        else if (e.key === "ArrowRight") goPage(1);
        else if (e.key === "ArrowLeft") goPage(-1);
      }
    });

    // 标签筛选
    document.querySelectorAll(".trend-filter-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        curTag = btn.dataset.tag;
        document.querySelectorAll(".trend-filter-btn").forEach(b => b.classList.toggle("active", b === btn));
        renderList();
      });
    });

    Common.setupAntiDownload(); // 防下载（统一实现）
    // 立即判断当前是否已登录
    SB.getSession().then(s => { window.__loggedIn = !!s; refreshUI(); }).catch(() => refreshUI());

    // ===== 公告弹窗事件 =====
    document.querySelectorAll(".top-tabs [data-viewtab]").forEach(a => {
      if (a.dataset.viewtab === "recruit") a.addEventListener("click", goRecruit);
      else if (a.dataset.viewtab === "bestseller") a.addEventListener("click", goBestseller);
      else if (a.dataset.viewtab === "trend") a.addEventListener("click", goTrend);
    });
    window.addEventListener("hashchange", () => showMain());

    // 未登录：点击跳转"视觉专区/返回视觉专区"(index.html)时强制回登录页，不允许跳到视觉专区
    document.querySelectorAll('a[href="index.html"]').forEach(a => {
      a.addEventListener("click", (e) => {
        if (window.__loggedIn) return; // 已登录正常跳转
        e.preventDefault();
        showLogin(); // 未登录一律回登录
      });
    });

    // ===== 公告弹窗事件（统一由 common.js 绑定） =====
    Common.notices.configure({ autoShowNeedsLogin: true, timeStyle: "full" });
    Common.notices.bind();
    onAuthRefreshNotices();
  });

  // 登录态变化后刷新公告角标/弹窗（逻辑在 common.js）
  async function onAuthRefreshNotices() {
    Common.notices.load();
    SB.onAuth(() => Common.notices.load());
  }

  // 前台图片"观看无印、下载带水印"：把图片绘制到 canvas 并叠加品牌水印后下载。
  // 页面展示仍用原图（无水印），仅当用户触发下载（右键等）时生成带水印版。

  function hideSplash() {
    const s = document.getElementById("boot-splash");
    if (s) s.classList.add("hidden");
  }

  async function refreshUI() {
    await ensureZoneVis();
    if (window.__loggedIn) { showTrend(); } else if (isSharePreview()) {
      // 分享预览（方案A）：未登录但带 ?zone= & cat= ，直接进入分享专区显示缩略图
      showMain();
    } else { showLogin(); }
    hideSplash();
  }
  function applyAuthMode() {
    const toggle = $("#auth-toggle-link");
    if (toggle) toggle.textContent = authMode === "login" ? "没有账号？注册一个" : "已有账号？去登录";
    const t = $("#auth-title"); if (t) t.textContent = authMode === "login" ? "趋势专区登录" : "注册账号";
    const s = $("#auth-submit"); if (s) s.textContent = authMode === "login" ? "进入趋势专区" : "注册并进入";
  }
  function showAuthHint(msg) {
    const h = $("#auth-hint");
    if (h) { h.textContent = msg; h.classList.remove("hidden"); }
  }
  // 注册后若开启邮箱确认：展示醒目的确认引导面板，隐藏登录表单，支持重新发送确认邮件

  function hideAuthHint() {
    const h = $("#auth-hint");
    if (h) h.classList.add("hidden");
  }
  // 邮箱输入 @ 后弹出常用域名，帮助快速补全
  function bindEmailSuggest() {
    const EMAIL_DOMAINS = ["gmail.com", "outlook.com", "qq.com", "163.com", "126.com", "hotmail.com", "foxmail.com", "sina.com"];
    const input = $("#auth-email");
    const box = document.getElementById("email-suggest");
    if (!input || !box) return;
    const hide = () => { box.classList.add("hidden"); box.innerHTML = ""; };
    const apply = (d) => {
      const cur = input.value;
      const at = cur.lastIndexOf("@");
      if (at >= 0) {
        input.value = cur.slice(0, at + 1) + d;
        try { input.setSelectionRange(cur.length, cur.length); } catch (e) {}
        input.focus();
      }
      hide();
    };
    input.addEventListener("input", () => {
      const v = input.value;
      const at = v.lastIndexOf("@");
      if (at < 0) { hide(); return; }
      const tail = v.slice(at + 1).toLowerCase();
      if (tail.indexOf(".") >= 0 || tail.length > 0 && /[\s@]/.test(tail)) { hide(); return; }
      const matched = EMAIL_DOMAINS.filter(d => d.indexOf(tail) === 0);
      if (!matched.length) { hide(); return; }
      box.innerHTML = "";
      matched.forEach(d => {
        const el = document.createElement("div");
        el.textContent = d;
        el.addEventListener("mousedown", (e) => { e.preventDefault(); apply(d); });
        box.appendChild(el);
      });
      box.classList.remove("hidden");
    });
    input.addEventListener("blur", () => setTimeout(hide, 160));
    document.addEventListener("click", (e) => { if (box.contains(e.target)) return; hide(); });
    // 登录/注册成功后、以及进入登录页时清空联想
    window.addEventListener("beforeunload", hide);
  }
  function showLogin() {
    authMode = "register";
    applyAuthMode();
    hideAuthHint();
    $("#login-view").classList.remove("hidden");
    $("#trend-view").classList.add("hidden");
    $("#recruit-view").classList.add("hidden");
    $("#bestseller-view").classList.add("hidden");
    $("#changepwd-btn").classList.add("hidden");
    $("#logout-btn").classList.add("hidden");
    // 登录页隐藏顶部导航栏，避免专区菜单残留
    const tb = document.getElementById("front-topbar");
    if (tb) tb.classList.add("hidden");
    setBanner(false);
  }
  function showMain() {
    $("#login-view").classList.add("hidden");
    $("#changepwd-btn").classList.remove("hidden");
    $("#logout-btn").classList.remove("hidden");
    // 进入专区恢复顶部导航栏
    const tb = document.getElementById("front-topbar");
    if (tb) tb.classList.remove("hidden");
    const hash = (location.hash || "").replace("#", "");
    let rec = hash === "recruit";
    let bs = hash === "bestseller";
    // —— 专区守卫：目标专区在前台被隐藏时，即使直接输入地址/哈希也拦截进入 ——
    const targetZone = bs ? "bestseller" : (rec ? "recruit" : "trend");
    if (!zoneVisible(targetZone)) {
      location.hash = "";           // 清掉被隐藏专区哈希
      toast("该专区暂未开放", false);
      showLogin();                   // 未开放一律回登录页
      return;
    }
    // 分享目标：URL 带 ?zone= & cat= 且当前未设置分区 hash（首次进入分享链接）时，
    // 定位到对应专区与类目；用户点击顶栏切换置入 hash 后，优先按 hash 跳转，分享目标不再覆盖。
    const isFreshShareEntry = hash === "" && hasShareTarget();
    if (isFreshShareEntry && shareZone === "recruit") { rec = true; bs = false; }
    else if (isFreshShareEntry && shareZone === "bestseller") { rec = false; bs = true; }
    if (isFreshShareEntry && shareCat) {
      if (shareZone === "recruit") recruitCat = shareCat;
      else if (shareZone === "bestseller") bestsellerCat = shareCat;
    }
    $("#trend-view").classList.toggle("hidden", rec || bs);
    $("#recruit-view").classList.toggle("hidden", !rec);
    $("#bestseller-view").classList.toggle("hidden", !bs);
    const brand = $("#front-brand");
    const zoneName = bs ? " · BESTSELLER" : (rec ? " · 招品回品" : " · 趋势专区");
    if (brand) brand.textContent = (CONFIG.siteTitle || "TREND BANK") + zoneName;
    document.title = (CONFIG.siteTitle || "TREND BANK") + zoneName;
    const activeTab = bs ? "bestseller" : (rec ? "recruit" : "trend");
    document.querySelectorAll(".top-tabs [data-viewtab]").forEach(a => a.classList.toggle("active", a.dataset.viewtab === activeTab));
    if (rec) loadRecruitView(); else if (bs) loadBestsellerView(); else loadTrends();
    // 横幅仅招品回品 / BESTSELLER 显示
    setBanner(rec || bs);
  }
  function showTrend() { showMain(); }
  // 未登录：仅当跳转目标是"分享目标专区"时才放行，否则回登录页
  function guardZone(zone) {
    // 专区守卫：该专区在前台被隐藏时，无论是否登录一律拦截，不放行进入
    if (!zoneVisible(zone)) {
      toast("该专区暂未开放", false);
      showLogin();
      return false;
    }
    if (window.__loggedIn) return true;
    // 分享预览仅在分享目标专区放行；趋势专区/其它专区一律回登录
    if (zone === "trend") { showLogin(); return false; }
    if (hasShareTarget() && shareZone === zone) return true;
    showLogin();
    return false;
  }
  function goRecruit(e) {
    if (e) { e.preventDefault(); }
    if (!guardZone("recruit")) return;
    location.hash = "recruit";
    showMain();
  }
  function goBestseller(e) {
    if (e) { e.preventDefault(); }
    if (!guardZone("bestseller")) return;
    location.hash = "bestseller";
    showMain();
  }
  function goTrend(e) {
    if (e) { e.preventDefault(); }
    if (!guardZone("trend")) return;
    location.hash = "";
    showMain();
  }

  async function onLogin(e) {
    e.preventDefault();
    const email = $("#auth-email").value.trim();
    const pass = $("#auth-pass").value;
    if (!email || !pass) return toast("请填写邮箱和密码", false);
    try {
      if (authMode === "register") {
        const { data, error } = await SB.signUp(email, pass);
        if (error) throw error;
        if (data && data.session) {
          // 后台未开启邮箱确认 → 直接自动登录
          window.__loggedIn = true;
          toast("注册成功，已登录");
          showTrend();
        } else {
          // 后台开启了邮箱确认（Confirm email）→ 需点邮件链接激活
          toast("注册成功！请到邮箱完成确认", true);
          Common.authConfirm.show(email);
          authMode = "login";
          applyAuthMode();
        }
        return;
      }
      const { data, error } = await SB.signIn(email, pass);
      if (error) {
        // 区分"账号错误 / 密码错误"：先判断该邮箱是否已注册
        let exists = null;
        try { exists = await SB.isEmailRegistered(email); } catch (e2) { exists = null; }
        if (exists === false) {
          toast("账号错误：该邮箱未注册，请先注册", false);
        } else if (exists === true) {
          toast("密码错误：请检查密码后重试", false);
        } else {
          toast("登录失败：" + (error.message || "请检查邮箱密码"), false);
        }
        return;
      }
      window.__loggedIn = true;
      toast("登录成功");
      showTrend();
    } catch (err) {
      toast("登录失败：" + (err.message || "请检查邮箱密码"), false);
    }
  }

  async function onLogout() {
    try {
      await SB.signOut();
      window.__loggedIn = false;
      toast("已退出");
      showLogin();
    } catch (e) {
      toast("退出失败", false);
    }
  }

  // 确保专区可见性已加载（仅加载一次），供守卫与导航复用
  async function ensureZoneVis() {
    if (zoneVisLoaded) return;
    try { zoneVis = await SB.getFrontendZoneVisibility(); } catch (e) { zoneVis = {}; }
    // 当前登录用户的用户级可见专区白名单（未登录/未配置 = null，回退全局）
    try { myZones = await SB.myFrontendZones(); } catch (e) { myZones = null; }
    zoneVisLoaded = true;
    if (window.Common && Common.zones) { Common.zones.setVis(zoneVis); Common.zones.setMine(myZones); Common.zones.loadDefs(); }
    applyZoneNav();
  }

  async function loadTrends() {
    try {
      try { catVisibility = await SB.getFrontendCatVisibility(); } catch (e) { catVisibility = {}; }
      await ensureZoneVis();
      trends = await SB.listTrends();
      const active = await SB.listActiveCats().catch(() => []);
      const activeArr = (active || []).map(c => (typeof c === "string" ? c : (c && c.name) || ""));
      const used = [...new Set(trends.map(t => t.category || "").filter(Boolean))];
      shownCats = activeArr.filter(c => used.includes(c) && catCatVisible("trend", c));
      renderCatMenu();
      renderList();
    } catch (e) {
      toast("加载趋势失败，请检查网络", false);
    }
  }

  // 某专区某类目是否前台可见（未配置默认可见）
  function catCatVisible(zone, cat) {
    const m = catVisibility && catVisibility[zone];
    return !m || m[cat] !== false;
  }

  // 某专区本身是否前台可见（未配置默认可见）
  // 优先按当前登录用户级白名单（myZones 非空数组）判断；未配置/未登录回退到全局 frontend_zone_visibility。
  function zoneVisible(zone) {
    if (Array.isArray(myZones) && myZones.length) {
      // 用户级白名单：仅白名单内专区可见；若全局也显式隐藏该专区则仍隐藏
      if (zoneVis && zoneVis[zone] === false) return false;
      return myZones.indexOf(zone) !== -1;
    }
    return !zoneVis || zoneVis[zone] !== false;
  }

  // 顶部菜单：每个菜单项（视觉/趋势/招品/BESTSELLER/公告）都可单独在前台被隐藏；
  // 被隐藏的菜单项导航不显示，直接访问/点击仍由 guardZone/showMain 守卫拦截。
  function applyZoneNav() {
    // 统一走公共专区模块（与榜单页/视觉专区/营销日历同一套逻辑）
    if (window.Common && Common.zones && Common.zones.applyNav) { Common.zones.applyNav(); return; }
    document.querySelectorAll(".top-tabs .tab-link").forEach(a => {
      const href = a.getAttribute("href") || "";
      const vt = a.getAttribute("data-viewtab") || "";
      let z = null;
      if (vt === "marketing" || href === "marketing.html") z = "marketing";
      else if (href === "index.html") z = "visual";
      else if (vt === "trend" || href === "trends.html") z = "trend";
      else if (vt === "recruit" || href === "trends.html#recruit") z = "recruit";
      else if (vt === "bestseller" || href === "trends.html#bestseller") z = "bestseller";
      else if (a.id === "notice-tab") z = "notice";
      a.style.display = (z && !zoneVisible(z)) ? "none" : "";
    });
  }

  function renderCatMenu() {
    const menu = $("#cat-menu");
    if (!menu) return;
    menu.innerHTML = "";
    ["全部"].concat(shownCats).forEach(c => {
      const b = document.createElement("button");
      b.className = "cat-menu-item" + (c === curCat ? " active" : "");
      b.textContent = c;
      b.onclick = () => { curCat = c; renderCatMenu(); renderList(); };
      menu.appendChild(b);
    });
  }

  function renderList() {
    const list = trends.filter(t =>
      catCatVisible("trend", t.category) &&
      (curTag === "全部" || t.tag === curTag) &&
      (curCat === "全部" || !curCat || t.category === curCat)
    );
    const box = $("#trend-list");
    if (!box) return;
    box.innerHTML = "";
    $("#trend-empty").classList.toggle("hidden", list.length > 0);
    list.forEach(t => {
      const card = document.createElement("div");
      card.className = "trend-card tc-grid";
      const cov = document.createElement("div");
      cov.className = "trend-card-cover";
      if (t.cover) {
        cov.classList.add("img");
        SB.trendCoverUrl(t.cover).then(u => {
          const im = document.createElement("img");
          im.src = u; im.alt = ""; im.draggable = false; im.loading = "lazy";
          im.addEventListener("contextmenu", (e) => e.preventDefault());
          cov.appendChild(im);
        }).catch(() => {});
      } else {
        cov.innerHTML = '<span class="tcov-ic">PDF</span>';
      }
      const body = document.createElement("div");
      body.className = "trend-card-body";
      const title = document.createElement("div");
      title.className = "trend-card-title";
      title.textContent = t.title || "未命名";
      const meta = document.createElement("div");
      meta.className = "trend-card-meta";
      meta.innerHTML = '<span class="trend-tag">' + escapeHtml(t.tag || "") + '</span>' +
        (t.category ? '<span class="trend-tag trend-cat">' + escapeHtml(t.category) + '</span>' : '');
      body.appendChild(title);
      if (t.description) {
        const d = document.createElement("div");
        d.className = "trend-card-desc";
        d.textContent = t.description;
        body.appendChild(d);
      }
      body.appendChild(meta);
      const open = document.createElement("button");
      open.className = "btn-ghost trend-open";
      open.textContent = "预览";
      open.addEventListener("click", () => openPdf(t));
      card.appendChild(cov);
      card.appendChild(body);
      card.appendChild(open);
      box.appendChild(card);
    });
  }

  async function loadRecruitView() {
    try {
      try { catVisibility = await SB.getFrontendCatVisibility(); } catch (e) { catVisibility = {}; }
      recruitCurUid = "";
      try { const sess = await SB.getSession(); recruitCurUid = (sess && sess.user && sess.user.id) || ""; } catch (e) {}
      [recruitTasks, recruitSubs, recruitCats] = await Promise.all([
        SB.listRecruitTasks({ status: "published" }),  // 前台只显示已发布
        SB.listAllRecruitSubmissions().catch(() => []),
        SB.listZoneCats("recruit").catch(() => []),
      ]);
      // 后台标记「无需回品」的任务前台不展示
      recruitTasks = recruitTasks.filter(t => !t.flag_no_refill);
      renderRecruitCatMenu();
      renderRecruitCards();
    } catch (e) {
      toast("加载招品失败", false);
    }
  }
  function renderRecruitCatMenu() {
    const menu = $("#recruit-cat-menu");
    if (!menu) return;
    const used = [...new Set(recruitTasks.map(t => t.category || "").filter(Boolean))];
    const cats = ["全部"].concat(recruitCats.map(c => c.name).filter(n => used.includes(n) && catCatVisible("recruit", n)));
    menu.innerHTML = "";
    cats.forEach(c => {
      const b = document.createElement("button");
      b.className = "cat-menu-item" + (c === recruitCat ? " active" : "");
      b.textContent = c;
      b.onclick = () => { recruitCat = c; renderRecruitCatMenu(); renderRecruitCards(); };
      menu.appendChild(b);
    });
  }
  function recruitSubsFor(taskId) {
    return recruitSubs.filter(s => s.recruit_task_id === taskId);
  }
  function renderRecruitCards() {
    const box = $("#recruit-list");
    if (!box) return;
    box.innerHTML = "";
    const list = recruitTasks.filter(t => catCatVisible("recruit", t.category) && (recruitCat === "全部" || !recruitCat || t.category === recruitCat));
    if (!list.length) {
      box.innerHTML = isSharePreview()
        ? '<div class="share-preview-tip">该分类暂无已发布内容。登录后查看全部招品任务。<a href="#recruit" onclick="location.hash=\"recruit\"">去登录</a></div>'
        : '<p class="empty-tip">该分类暂无招品任务。</p>';
      return;
    }
    list.forEach((t, idx) => {
      const mySub = recruitSubsFor(t.id).find(s => s.user_id === recruitCurUid);
      const mySpus = (mySub && mySub.spus) ? mySub.spus.filter(Boolean) : [];
      const seq = idx + 1;
      const card = document.createElement("div");
      card.className = "recruit-card";
      const previewMode = isSharePreview();
      // 招品信息区（前台展示：站点/提需到日/优先级/原因/类目）
      const siteName = window.CONFIG.siteName(t.site_id) || "";
      const infoParts = [];
      if (t.category) infoParts.push('<span class="ri-cat">类目：' + escHtml(t.category) + '</span>');
      if (siteName) infoParts.push('<span class="ri-site">站点：' + escHtml(siteName) + '</span>');
      if (t.required_at) infoParts.push('<span class="ri-time">提需：' + escHtml(frontDay(t.required_at)) + '</span>');
      if (t.open_priority) infoParts.push('<span class="ri-pri">优先级：' + escHtml(t.open_priority) + '</span>');
      if (t.recruit_reason) infoParts.push('<span class="ri-reason">原因：' + escHtml(t.recruit_reason) + '</span>');
      const infoHtml = infoParts.length ? '<div class="recruit-info">' + infoParts.join('') + '</div>' : '';
      card.innerHTML =
        '<div class="recruit-img">' +
          '<img class="recruit-thumb" alt="">' +
          '<span class="recruit-ph">图片加载中</span>' +
          '<span class="recruit-no"></span>' + (mySpus.length && !previewMode ? '<span class="recruit-done">已上传</span>' : '') +
        '</div>' +
        '<div class="recruit-body">' +
          infoHtml +
          (!previewMode
            ? '<div class="recruit-spu-sub"></div>' +
              '<div class="recruit-form hidden">' +
                '<input class="recruit-spu-input" placeholder="填写货品SPU，多个用英文逗号分隔">' +
                '<button type="button" class="btn-primary rec-save">保存</button>' +
              '</div>' +
              '<div class="recruit-ops">' +
                '<button type="button" class="btn-ghost rec-upload">上传货品SPU</button>' +
                '<button type="button" class="btn-ghost rec-edit">编辑</button>' +
              '</div>'
            : '<div class="recruit-share-cta">登录后查看高清与提交SPU <a href="#recruit">登录/注册</a></div>') +
        '</div>';
      const img = card.querySelector(".recruit-img");
      const im = card.querySelector(".recruit-thumb");
      const ph = card.querySelector(".recruit-ph");
      card.querySelector(".recruit-no").textContent = seq;
      if (t.main_img_url) {
        im.src = t.main_img_url;
        im.onload = () => { im.style.opacity = "1"; ph.classList.add("hidden"); };
        im.onerror = () => { im.style.opacity = "0"; ph.textContent = "图片暂不可见"; };
      } else if (t.image_path) {
        SB.recruitImageUrl(t.image_path).then(u => {
          im.onload = () => { im.style.opacity = "1"; ph.classList.add("hidden"); };
          im.onerror = () => { im.style.opacity = "0"; ph.textContent = "图片暂不可见"; };
          im.src = u;
        }).catch(() => { ph.textContent = "图片暂不可见"; });
      } else {
        ph.textContent = "暂无图片";
      }
      const jumpLink = (t.industry_link || "").trim();
      if (jumpLink) { im.style.cursor = "pointer"; }
      const onImgClick = (e) => {
        if (jumpLink) { e.stopPropagation(); window.open(jumpLink, "_blank", "noopener"); return; }
        if (previewMode) { location.hash = "recruit"; toast("请登录后查看高清原图与提交SPU"); }
      };
      im.addEventListener("click", onImgClick);
      if (previewMode) {
        box.appendChild(card);
        return;
      }
      const subEl = card.querySelector(".recruit-spu-sub");
      if (mySpus.length) { subEl.textContent = "我已上传 " + mySpus.length + " 个SPU"; } else { subEl.textContent = "尚未上传货品SPU"; }
      const tip = mySpus.length ? ("我上传的货品SPU：\n" + mySpus.join("\n")) : "尚未上传货品SPU";
      img.title = tip;
      const form = card.querySelector(".recruit-form");
      const ops = card.querySelector(".recruit-ops");
      const inp = card.querySelector(".recruit-spu-input");
      const openForm = (prefill) => {
        inp.value = mySpus.length && prefill ? mySpus.join(",") : "";
        ops.classList.add("hidden");
        form.classList.remove("hidden");
        inp.focus();
      };
      card.querySelector(".rec-upload").addEventListener("click", () => openForm(false));
      card.querySelector(".rec-edit").addEventListener("click", () => openForm(true));
      card.querySelector(".rec-save").addEventListener("click", () => saveMySpu(t, card, ops, form));
      box.appendChild(card);
    });
  }
  async function saveMySpu(t, card, ops, form) {
    const inp = card.querySelector(".recruit-spu-input");
    const raw = inp ? inp.value.trim() : "";
    const spus = raw.split(/[,，、\s]+/).map(x => x.trim()).filter(Boolean);
    try {
      await SB.upsertRecruitSubmission(t.id, spus);
      toast(spus.length ? "已保存 " + spus.length + " 个SPU" : "已保存");
      loadRecruitView();
    } catch (e) {
      toast("保存失败：" + (e.message || ""), false);
    }
  }

  async function loadBestsellerView() {
    try {
      try { catVisibility = await SB.getFrontendCatVisibility(); } catch (e) { catVisibility = {}; }
      bestsellerCurUid = "";
      try { const sess = await SB.getSession(); bestsellerCurUid = (sess && sess.user && sess.user.id) || ""; } catch (e) {}
      [bestsellerTasks, bestsellerSubs, bestsellerCats] = await Promise.all([
        SB.listBestsellerTasks({ status: "published" }),
        SB.listAllBestsellerSubmissions().catch(() => []),
        SB.listZoneCats("bestseller").catch(() => []),
      ]);
      // 后台标记「无需回品」的任务前台不展示
      bestsellerTasks = bestsellerTasks.filter(t => !t.flag_no_refill);
      renderBestsellerCatMenu();
      renderBestsellerCards();
    } catch (e) { toast("加载BESTSELLER失败", false); }
  }
  function renderBestsellerCatMenu() {
    const menu = $("#bestseller-cat-menu");
    if (!menu) return;
    const used = [...new Set(bestsellerTasks.map(t => t.category || "").filter(Boolean))];
    const cats = ["全部"].concat(bestsellerCats.map(c => c.name).filter(n => used.includes(n) && catCatVisible("bestseller", n)));
    menu.innerHTML = "";
    cats.forEach(c => {
      const b = document.createElement("button");
      b.className = "cat-menu-item" + (c === bestsellerCat ? " active" : "");
      b.textContent = c;
      b.onclick = () => { bestsellerCat = c; renderBestsellerCatMenu(); renderBestsellerCards(); };
      menu.appendChild(b);
    });
  }
  function bestsellerSubsFor(taskId) {
    return bestsellerSubs.filter(s => s.bestseller_task_id === taskId);
  }
  function renderBestsellerCards() {
    const box = $("#bestseller-list");
    if (!box) return;
    box.innerHTML = "";
    const list = bestsellerTasks.filter(t => catCatVisible("bestseller", t.category) && (bestsellerCat === "全部" || !bestsellerCat || t.category === bestsellerCat));
    if (!list.length) {
      box.innerHTML = isSharePreview()
        ? '<div class="share-preview-tip">该分类暂无已发布内容。登录后查看全部BESTSELLER任务。<a href="#bestseller">去登录</a></div>'
        : '<p class="empty-tip">该分类暂无BESTSELLER任务。</p>';
      return;
    }
    list.forEach((t, idx) => {
      const mySub = bestsellerSubsFor(t.id).find(s => s.user_id === bestsellerCurUid);
      const mySpus = (mySub && mySub.spus) ? mySub.spus.filter(Boolean) : [];
      const seq = idx + 1;
      const card = document.createElement("div");
      card.className = "recruit-card";
      const previewMode = isSharePreview();
      card.innerHTML =
        '<div class="recruit-img">' +
          '<img class="recruit-thumb" alt="">' +
          '<span class="recruit-ph">图片加载中</span>' +
          '<span class="recruit-no"></span>' + (mySpus.length && !previewMode ? '<span class="recruit-done">已上传</span>' : '') +
          (!previewMode && t.url ? '<a class="recruit-ext" href="' + escapeHtml(t.url) + '" target="_blank" rel="noopener nofollow">🔗打开链接</a>' : '') +
          (previewMode ? '' : '<div class="bestseller-cinfo"><div class="bestseller-cinfo-inner"></div></div>') +
        '</div>' +
        '<div class="recruit-body">' +
          (!previewMode
            ? '<div class="recruit-spu-sub"></div>' +
              '<div class="recruit-form hidden">' +
                '<input class="recruit-spu-input" placeholder="填写货品SPU，多个用英文逗号分隔">' +
                '<button type="button" class="btn-primary rec-save">保存</button>' +
              '</div>' +
              '<div class="recruit-ops">' +
                '<button type="button" class="btn-ghost rec-upload">上传货品SPU</button>' +
                '<button type="button" class="btn-ghost rec-edit">编辑</button>' +
              '</div>'
            : '<div class="recruit-share-cta">登录后查看高清与提交SPU <a href="#bestseller">登录/注册</a></div>') +
        '</div>';
      const img = card.querySelector(".recruit-img");
      const im = card.querySelector(".recruit-thumb");
      const ph = card.querySelector(".recruit-ph");
      card.querySelector(".recruit-no").textContent = seq;
      if (t.main_img_url) {
        // 直接用主图URL显示
        im.onload = () => { im.style.opacity = "1"; ph.classList.add("hidden"); };
        im.onerror = () => { im.style.opacity = "0"; ph.textContent = "图片暂不可见"; };
        im.src = t.main_img_url;
      } else if (t.image_path) {
        SB.bestsellerImageUrl(t.image_path).then(u => {
          im.onload = () => { im.style.opacity = "1"; ph.classList.add("hidden"); };
          im.onerror = () => { im.style.opacity = "0"; ph.textContent = "图片暂不可见"; };
          im.src = u;
        }).catch(() => { ph.textContent = "图片暂不可见"; });
      } else { ph.textContent = "暂无图片"; }
      // 分享预览：只展示缩略图，隐藏商品信息/外链/SPU，点图弹登录
      if (previewMode) {
        im.addEventListener("click", () => {
          location.hash = "bestseller";
          toast("请登录后查看高清原图与提交SPU");
        });
        box.appendChild(card);
        return;
      }
      // 鼠标悬停图片展示商品信息（ID / SKUID / 站点 / 最新上榜时间）
      const cinfo = card.querySelector(".bestseller-cinfo");
      if (cinfo && (t.goods_id || t.sku_id || t.site || t.rank_time)) {
        const lines = [];
        if (t.goods_id) lines.push("ID：" + escapeHtml(t.goods_id));
        if (t.sku_id) lines.push("SKUID：" + escapeHtml(t.sku_id));
        if (t.site) lines.push("站点：" + escapeHtml(t.site));
        if (t.rank_time) lines.push("最新上榜时间：" + escapeHtml(t.rank_time));
        cinfo.querySelector(".bestseller-cinfo-inner").innerHTML = '<div class="bestseller-cinfo-t">信息</div>' + lines.map(l => '<div class="bestseller-cinfo-line">' + l + '</div>').join("");
      }
      // 点击图片跳转链接（main_img_url 外链或 url）
      if (img) {
        img.classList.add("bs-clickable");
      }
      const subEl = card.querySelector(".recruit-spu-sub");
      if (mySpus.length) { subEl.textContent = "我已上传 " + mySpus.length + " 个SPU"; } else { subEl.textContent = "尚未上传货品SPU"; }
      const tip = mySpus.length ? ("我上传的货品SPU：\n" + mySpus.join("\n")) : "尚未上传货品SPU";
      img.title = tip;
// 点击图片跳转链接（BESTSELLER 主图URL/链接）
      if (img) {
        img.style.cursor = t.url ? "pointer" : img.style.cursor;
        if (t.url) {
          img.addEventListener("click", () => { window.open(t.url, "_blank", "noopener,noreferrer"); });
        }
      }
      const form = card.querySelector(".recruit-form");
      const ops = card.querySelector(".recruit-ops");
      const inp = card.querySelector(".recruit-spu-input");
      const openForm = (prefill) => { inp.value = mySpus.length && prefill ? mySpus.join(",") : ""; ops.classList.add("hidden"); form.classList.remove("hidden"); inp.focus(); };
      card.querySelector(".rec-upload").addEventListener("click", () => openForm(false));
      card.querySelector(".rec-edit").addEventListener("click", () => openForm(true));
      card.querySelector(".rec-save").addEventListener("click", () => saveMyBsSpu(t, card));
      box.appendChild(card);
    });
  }
  async function saveMyBsSpu(t, card) {
    const inp = card.querySelector(".recruit-spu-input");
    const raw = inp ? inp.value.trim() : "";
    const spus = raw.split(/[,，、\s]+/).map(x => x.trim()).filter(Boolean);
    try { await SB.upsertBestsellerSubmission(t.id, spus); toast(spus.length ? "已保存 " + spus.length + " 个SPU" : "已保存"); loadBestsellerView(); }
    catch (e) { toast("保存失败：" + (e.message || ""), false); }
  }

  function escapeHtml(s) {
    return String(s || "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  /* ============================================================================
   * 受控预览（20261030F 重做）
   * ----------------------------------------------------------------------------
   * 原来一次只画一页、靠「上一页 / 下一页」翻，两个毛病：
   *   · 每次打开都重新下载 + 重新解析整个 PDF，关掉再开又从头来一遍 → 慢
   *   · 单页 canvas 撑不满窗口，翻页要点，读长报告很累
   * 现在改为：
   *   · 按文件路径缓存已解析的文档，第二次打开直接出图
   *   · 连续纵向滚动，滚动到哪页才画哪页（IntersectionObserver 懒渲染）
   *   · 可全屏、可缩放，「适宽」一键回到满宽
   * 仍然用 pdf.js 自绘，不给任何下载 / 打印入口。
   * ==========================================================================*/
  async function openPdf(t) {
    const stage = $("#pdf-stage"), pages = $("#pdf-pages"), loading = $("#pdf-loading");
    try {
      if (!window.pdfjsLib) { toast("预览组件未就绪，请刷新重试", false); return; }
      closePdf(true);                       /* 关掉上一个，但不清缓存 */
      pdfPath = t.path || "";
      $("#pdf-title").textContent = t.title || "预览";
      $("#pdf-modal").classList.remove("hidden");
      loading.textContent = "正在加载预览…";
      loading.classList.remove("hidden");
      pages.innerHTML = "";

      /* 命中缓存就直接用，省掉下载和解析 —— 这是之前「再开一次还是很慢」的根因 */
      let doc = pdfCache.get(pdfPath) && pdfCache.get(pdfPath).doc;
      if (!doc) {
        /* 先要一个带签名的地址，再取二进制 */
        const url = await SB.trendPreviewUrl(t.path);
        const buf = await fetchPdfWithProgress(url, loading);
        loading.textContent = "正在解析文档…";
        pdfLoadTask = window.pdfjsLib.getDocument({ data: buf });
        doc = await pdfLoadTask.promise;
        pdfLoadTask = null;
        pdfCache.set(pdfPath, { doc: doc, buf: buf });
        /* 只留最近几份，超出的销毁最旧的 */
        if (pdfCache.size > PDF_CACHE_MAX) {
          const firstKey = pdfCache.keys().next().value;
          if (firstKey !== pdfPath) {
            const old = pdfCache.get(firstKey);
            pdfCache.delete(firstKey);
            if (old && old.doc) { try { old.doc.destroy(); } catch (e) {} }
          }
        }
      }
      pdfDoc = doc;
      pdfPage = 1;
      pdfScale = 1.0;

      /* 用第 1 页的宽高比给所有页占位，滚动条长度一次算对，不会边滚边跳 */
      const p1 = await doc.getPage(1);
      const vp1 = p1.getViewport({ scale: 1 });
      const ratio = vp1.height / vp1.width;

      pdfPages = [];
      for (let i = 1; i <= doc.numPages; i++) {
        const wrap = document.createElement("div");
        wrap.className = "pdf-page-wrap";
        wrap.dataset.page = String(i);
        const cv = document.createElement("canvas");
        cv.className = "pdf-page-canvas";
        wrap.appendChild(cv);
        pages.appendChild(wrap);
        pdfPages.push({ wrap: wrap, canvas: cv, rendered: false, task: null, ratio: ratio });
      }

      await relayoutPdf();                  /* 先把尺寸算好 */
      loading.classList.add("hidden");
      $("#pdf-page").textContent = "1 / " + doc.numPages;

      /* 首屏两页立刻画，其余滚到再画 —— 页数多时不会一开就卡住 */
      renderPdfAt(0);
      renderPdfAt(1);
      observePdf();
    } catch (e) {
      loading.textContent = "预览加载失败，请稍后重试";
      loading.classList.remove("hidden");
      toast("预览打开失败", false);
    }
  }

  /* 下载 PDF 二进制：边下边报进度。
     一份长页周报动辄十几 MB，以前 fetch 整个吞下去、页面只显示「正在加载预览…」，
     看起来就像卡死了；现在至少能看到百分比和已下多少 MB。 */
  async function fetchPdfWithProgress(url, loading) {
    const res = await fetch(url);
    if (!res.ok) throw new Error("load");
    const total = Number(res.headers.get("content-length") || 0);
    if (!res.body || !res.body.getReader) return await res.arrayBuffer();
    const reader = res.body.getReader();
    const chunks = [];
    let got = 0;
    for (;;) {
      const step = await reader.read();
      if (step.done) break;
      chunks.push(step.value);
      got += step.value.length;
      if (loading && !loading.classList.contains("hidden")) {
        const mb = (got / 1048576).toFixed(1);
        loading.textContent = total
          ? "正在下载 " + Math.min(99, Math.round((got / total) * 100)) + "%（" + mb + " / " + (total / 1048576).toFixed(1) + " MB）"
          : "正在下载 " + mb + " MB";
      }
    }
    const out = new Uint8Array(got);
    let off = 0;
    chunks.forEach((c) => { out.set(c, off); off += c.length; });
    return out.buffer;
  }

  /* 按容器宽度算每页显示尺寸；zoom 只改显示倍数，不重新下载文件 */
  async function relayoutPdf() {
    if (!pdfDoc || !pdfPages.length) return;
    const stage = $("#pdf-stage");
    const availW = Math.max(320, (stage ? stage.clientWidth : 900) - 48);
    const first = pdfPages[0];
    const p1 = await pdfDoc.getPage(1);
    const vp1 = p1.getViewport({ scale: 1 });
    pdfBaseScale = availW / vp1.width;       /* 满宽时的倍数 */

    pdfPages.forEach((p) => {
      const w = vp1.width * pdfBaseScale * pdfScale;
      const h = vp1.height * pdfBaseScale * pdfScale;
      p.wrap.style.width = Math.round(w) + "px";
      p.wrap.style.height = Math.round(h) + "px";
      p.rendered = false;                    /* 尺寸变了要重画 */
      const c = p.canvas;
      c.width = 0; c.height = 0;
      c.style.width = "100%";
      c.style.height = "100%";
    });
    $("#pdf-zoom").textContent = Math.round(pdfScale * 100) + "%";
    /* 重新画当前视野里的页 */
    pdfPages.forEach((p, i) => { if (nearViewport(p.wrap)) renderPdfAt(i); });
  }

  function nearViewport(el) {
    const stage = $("#pdf-stage");
    if (!stage || !el) return false;
    const sr = stage.getBoundingClientRect(), er = el.getBoundingClientRect();
    return er.bottom > sr.top - 600 && er.top < sr.bottom + 600;
  }

  /* 单页渲染的像素上限：
     老版周报是「一张页高 4800mm」的超长页，宽高比约 1:16，
     按满宽 + 1.5 倍像素比画出来是 1100×18000 = 2000 万像素（约 80MB）一张 canvas，
     画一张就好几秒，两张开屏直接上百 MB —— 这就是「打开要等很久」的主因。
     这里给高度封顶，超了就按比例降分辨率，画布面积可控，滚动也不再掉帧。 */
  const PDF_MAX_PX_H = 6000;
  const PDF_MAX_PX_W = 2400;

  async function renderPdfAt(idx) {
    const p = pdfPages[idx];
    if (!p || p.rendered || !pdfDoc) return;
    p.rendered = true;
    try {
      const page = await pdfDoc.getPage(idx + 1);
      const base = page.getViewport({ scale: 1 });
      let s = pdfBaseScale * pdfScale * (window.devicePixelRatio > 1 ? 1.5 : 1);
      /* 高度封顶：超长页降分辨率，宁可略糊也不要把主线程压死 */
      if (base.height * s > PDF_MAX_PX_H) s = PDF_MAX_PX_H / base.height;
      if (base.width * s > PDF_MAX_PX_W) s = Math.min(s, PDF_MAX_PX_W / base.width);
      const vp = page.getViewport({ scale: s });
      const cv = p.canvas;
      cv.width = Math.round(vp.width);
      cv.height = Math.round(vp.height);
      const ctx = cv.getContext("2d");
      const task = page.render({ canvasContext: ctx, viewport: vp });
      p.task = task;
      await task.promise;
      p.task = null;
    } catch (e) {
      p.rendered = false;                    /* 失败允许下次滚动重试 */
    }
  }

  /* 滚到哪页画哪页 */
  function observePdf() {
    if (pdfObserver) pdfObserver.disconnect();
    const stage = $("#pdf-stage");
    pdfObserver = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        const i = Number(en.target.dataset.page) - 1;
        renderPdfAt(i);
        pdfPage = i + 1;
        if (pdfDoc) $("#pdf-page").textContent = pdfPage + " / " + pdfDoc.numPages;
      });
    }, { root: stage, rootMargin: "300px 0px" });
    pdfPages.forEach((p) => pdfObserver.observe(p.wrap));
  }

  function setPdfZoom(z) {
    if (!pdfDoc) return;
    pdfScale = Math.min(3, Math.max(0.4, z));
    relayoutPdf();
  }

  /* 全屏：让弹窗铺满整屏，Esc 退出时把尺寸算回去 */
  function togglePdfFull() {
    const box = document.querySelector(".pdf-modal-box");
    if (!box) return;
    if (document.fullscreenElement) { document.exitFullscreen(); return; }
    if (box.requestFullscreen) box.requestFullscreen();
  }

  function closePdf(keepCache) {
    $("#pdf-modal").classList.add("hidden");
    if (pdfObserver) { pdfObserver.disconnect(); pdfObserver = null; }
    if (pdfLoadTask) { try { pdfLoadTask.destroy(); } catch (e) {} pdfLoadTask = null; }
    pdfPages.forEach((p) => { if (p.task) { try { p.task.cancel(); } catch (e) {} } });
    pdfPages = [];
    const pages = $("#pdf-pages");
    if (pages) pages.innerHTML = "";
    pdfDoc = null;
    if (!keepCache) pdfCache.clear();
  }
})();