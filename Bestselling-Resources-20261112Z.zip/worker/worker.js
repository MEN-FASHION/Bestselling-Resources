/* ============================================================
 * Cloudflare Worker —— TREND BANK 的"守门员"
 *
 * 职责：
 *   1) GET   /images/{category}/{file}  访客看图（必须携带 Supabase 登录令牌）
 *   2) POST  /upload                    管理员上传图片（令牌 + admin 角色）
 *   3) DELETE /images/{category}/{file} 管理员删除图片（令牌 + admin 角色）
 *
 * 部署方式（详见 README）：
 *   - R2 桶名与 Worker Binding 名都叫 IMAGES（可自行修改）
 *   - 环境变量：SUPABASE_URL（例如 https://xxxx.supabase.co）
 *   - 环境变量：SUPABASE_ANON_KEY（你的 anon public key）
 * ============================================================ */

// Supabase 用户查询：通过令牌换 user id（带短期缓存，避免每张图片请求都重复鉴权）
// 同一令牌 5 分钟内只校验一次，大幅减少一页多图时的鉴权往返
const _uidCache = new Map();
// 图片读取限流计数器：ip -> { count, resetAt }（内存级，零成本，防批量抓取）
const _imgHits = new Map();
async function getUserId(token, env) {
  if (!token) return null;
  const now = Date.now();
  const hit = _uidCache.get(token);
  if (hit && (now - hit.at) < 5 * 60 * 1000) return hit.id;
  const res = await fetch(env.SUPABASE_URL + "/auth/v1/user", {
    headers: { Authorization: "Bearer " + token, apikey: env.SUPABASE_ANON_KEY },
  });
  let id = null;
  if (res.ok) {
    const user = await res.json();
    id = user?.id || null;
  }
  // 只缓存「成功解析出用户」的结果。
  // 鉴权失败往往是一次性的（访问令牌刚过期、瞬时网络抖动），若把失败也缓存 5 分钟，
  // 该令牌后续所有图片请求都会被判未登录，表现为整页图片/图片清单打不开。
  if (id) _uidCache.set(token, { id, at: now });
  else _uidCache.delete(token);
  return id;
}

// 查询某用户在 profiles 表中的角色
async function getRole(userId, token, env) {
  const url = `${env.SUPABASE_URL}/rest/v1/profiles?user_id=eq.${encodeURIComponent(userId)}&select=role`;
  const res = await fetch(url, {
    headers: {
      apikey: env.SUPABASE_ANON_KEY,
      Authorization: "Bearer " + token,
    },
  });
  if (!res.ok) return null;
  const rows = await res.json();
  return rows && rows.length ? rows[0].role : null;
}

// 管理员判定：admin 与 super_admin 均具备管理员权限（超管拥有全部权限）
// 归一化：去首尾空格 + 转小写，避免角色值含空格/大小写差异导致误判
function isAdminRole(role) {
  const r = String(role || "").trim().toLowerCase();
  return r === "admin" || r === "super_admin";
}

// 超管判定：仅超级管理员（营销日历等超管专属能力）
function isSuperRole(role) {
  const r = String(role || "").trim().toLowerCase();
  return r === "super_admin";
}

// 查询某用户在 profiles 表中的专区白名单（manage_zones 数组）
async function getManageZones(userId, token, env) {
  try {
    const url = `${env.SUPABASE_URL}/rest/v1/profiles?user_id=eq.${encodeURIComponent(userId)}&select=manage_zones`;
    const res = await fetch(url, {
      headers: {
        apikey: env.SUPABASE_ANON_KEY,
        Authorization: "Bearer " + token,
      },
    });
    if (!res.ok) return [];
    const rows = await res.json();
    const z = rows && rows.length ? rows[0].manage_zones : null;
    return Array.isArray(z) ? z : [];
  } catch (e) { return []; }
}
// 专区授权判定：超管固定放行；未配置白名单的管理员默认放行；已配置则严格按白名单
async function canManageZone(userId, role, token, env, zone) {
  if (isSuperRole(role)) return true;
  if (!isAdminRole(role)) return false;
  const zones = await getManageZones(userId, token, env);
  if (!zones.length) return true;   // 未配置用户级专区：按全局放行（兼容）
  return zones.indexOf(zone) !== -1;
}

// 类目授权判定：超管放行；非管理员拒绝；管理员需专区授权 + 该类目在其 zone_permissions 内（类目为空则回退专区级）
async function canManageZoneCat(userId, role, token, env, zone, category) {
  if (isSuperRole(role)) return true;
  if (!isAdminRole(role)) return false;
  if (!(await canManageZone(userId, role, token, env, zone))) return false;
  if (!category || !String(category).trim()) return true;
  try {
    const cat = String(category).trim().toLowerCase();
    const url = `${env.SUPABASE_URL}/rest/v1/zone_permissions?user_id=eq.${encodeURIComponent(userId)}&zone=eq.${encodeURIComponent(zone)}&select=category`;
    const res = await fetch(url, {
      headers: { apikey: env.SUPABASE_ANON_KEY, Authorization: "Bearer " + token },
    });
    if (!res.ok) return false;
    const rows = await res.json();
    return (rows || []).some(r => String(r.category || "").trim().toLowerCase() === cat);
  } catch (e) { return false; }
}

// 通过 Auth Admin API 创建用户（邮箱 + 密码），仅超管可触发，需 service_role
async function adminCreateAuthUser(env, email, password) {
  const res = await fetch(env.SUPABASE_URL + "/auth/v1/admin/users", {
    method: "POST",
    headers: {
      apikey: env.SUPABASE_SERVICE_ROLE_KEY,
      Authorization: "Bearer " + env.SUPABASE_SERVICE_ROLE_KEY,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ email, password, email_confirm: true }),
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j.msg || j.message || "创建用户失败");
  return j;
}
// 通过 Auth Admin API 删除用户（级联删除 profiles 等，需服务端 RLS/RU 权限配合），仅超管
async function adminDeleteAuthUser(env, uid) {
  const res = await fetch(env.SUPABASE_URL + "/auth/v1/admin/users/" + encodeURIComponent(uid), {
    method: "DELETE",
    headers: {
      apikey: env.SUPABASE_SERVICE_ROLE_KEY,
      Authorization: "Bearer " + env.SUPABASE_SERVICE_ROLE_KEY,
    },
  });
  if (!res.ok) {
    const j = await res.json().catch(() => ({}));
    throw new Error(j.msg || j.message || "删除用户失败");
  }
}

// CORS 头
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Max-Age": "86400",
};

async function handleRequest(request, env) {
  const url = new URL(request.url);
  // 关键修复：浏览器请求时中文类目会被 URL 编码，这里必须还原成本地字符再查 R2（否则中文类目图片 404）
  let path;
  try {
    path = decodeURIComponent(url.pathname).replace(/^\//, "");
  } catch (e) {
    path = url.pathname.replace(/^\//, "");
  }
  const method = request.method;

  // 预检
  if (method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }

  // 登录令牌：优先 Authorization，其次 query 的 token（<img> 无法带头）
  const auth = request.headers.get("Authorization") || "";
  let token = auth.startsWith("Bearer ") ? auth.slice(7) : (url.searchParams.get("token") || "");
  const userId = await getUserId(token, env);

  // ---------- 0. GET /geo：返回访问者的网络出口信息（国家 / 省州 / 城市 / IP）----------
  // 供前台「数据看板」记录用户来源地区。只返回调用者自己的信息，不查库、不读他人数据。
  if (method === "GET" && path === "geo") {
    const cf = request.cf || {};
    return json({
      ip: request.headers.get("CF-Connecting-IP") || "",
      country: (cf.country || cf.countryCode || "").toString(),
      region: (cf.region || cf.regionCode || "").toString(),
      city: (cf.city || "").toString(),
    }, 200, CORS);
  }

// 读取前台公开浏览开关（site_settings.public_access），带 60 秒时间戳缓存避免每次查库
let _pubVal = false;
let _pubAt = 0;
async function isPublicAccess(env) {
  const now = Date.now();
  if (now - _pubAt < 60000) return _pubVal;
  try {
    const url = env.SUPABASE_URL + "/rest/v1/site_settings?select=public_access&id=eq.1";
    const res = await fetch(url, {
      headers: {
        apikey: env.SUPABASE_ANON_KEY,
        Authorization: "Bearer " + env.SUPABASE_ANON_KEY,
        "Content-Type": "application/json",
      },
    });
    const arr = await res.json();
    _pubVal = !!(Array.isArray(arr) && arr[0] && arr[0].public_access);
  } catch (e) {
    _pubVal = false;
  }
  _pubAt = now;
  return _pubVal;
}

// 外部只读取图开关（site_secrets）：独立于「前台公开浏览」，只影响匿名读图，不影响写操作
// 密钥存独立表且 RLS 全禁，只有服务端能读，前端与访客都拿不到
let _arVal = null;
let _arAt = 0;
async function getAgentRead(env, force) {
  const now = Date.now();
  if (!force && _arVal && now - _arAt < 60000) return _arVal;
  try {
    const res = await fetch(
      env.SUPABASE_URL + "/rest/v1/site_secrets?select=agent_read,agent_read_key&id=eq.1",
      {
        headers: {
          apikey: env.SUPABASE_SERVICE_ROLE_KEY,
          Authorization: "Bearer " + env.SUPABASE_SERVICE_ROLE_KEY,
          "Content-Type": "application/json",
        },
      }
    );
    const arr = await res.json();
    const r = Array.isArray(arr) && arr[0];
    _arVal = { on: !!(r && r.agent_read), key: (r && r.agent_read_key) || "" };
  } catch (e) {
    _arVal = { on: false, key: "" };
  }
  _arAt = now;
  return _arVal;
}

// 生成只读密钥（32 位十六进制）
function genReadKey() {
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  return Array.from(b).map(function (x) { return x.toString(16).padStart(2, "0"); }).join("");
}

  // 兼容新旧存储：新图明文存中文路径，旧图曾以编码形式存储，先取解码后路径，取不到再取原始编码路径
  async function getObject(decodedPath, rawPath) {
    let obj = await env.IMAGES.get(decodedPath);
    if (!obj && rawPath && rawPath !== decodedPath) obj = await env.IMAGES.get(rawPath);
    return obj;
  }

  // ---------- 图片读取限流 + 异常审计（防批量、事后兜底）----------
  // 每 IP 每分钟图片请求上限，超过则 429 并记录审计日志（内存级，零成本）
  if (method === "GET" && path.startsWith("images/")) {
    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    const now = Date.now();
    const WLIM = 2000;     // 每分钟上限（每 IP，便于正常列表批量看图；可自行调整）
    const WWIN = 60000;    // 窗口：1 分钟
    let h = _imgHits.get(ip);
    if (!h || now > h.resetAt) { h = { count: 0, resetAt: now + WWIN }; _imgHits.set(ip, h); }
    h.count++;
    if (h.count > WLIM) {
      console.log("[IMG-AUDIT] rate-limit ip=" + ip + " count=" + h.count + " path=" + path);
      return json({ error: "请求过于频繁" }, 429, CORS);
    }
    if (h.count === Math.floor(WLIM * 0.9)) {
      console.log("[IMG-AUDIT] near-limit ip=" + ip + " count=" + h.count);
    }
  }

  // ---------- 1. GET 看图：登录即可；公开浏览模式或外部只读密钥放行 ----------
  if (method === "GET" && path.startsWith("images/")) {
    if (!userId) {
      const pub = await isPublicAccess(env);
      if (!pub) {
        // 外部只读取图：开关开着且密钥匹配才放行，否则与未登录同等对待
        const ar = await getAgentRead(env);
        const gotKey = url.searchParams.get("read_key") || "";
        if (!(ar.on && ar.key && gotKey === ar.key)) {
          return json({ error: "未登录" }, 401, CORS);
        }
      }
    }
    const rawPath = url.pathname.replace(/^\//, "");
    const object = await getObject(path, rawPath);
    if (!object) return json({ error: "文件不存在" }, 404, CORS);
    const headers = new Headers(CORS);
    headers.set("Content-Type", object.httpMetadata?.contentType || "application/octet-stream");
    // 防下载：禁止嗅探、禁止作为附件下载、禁止被外站引用，且不暴露令牌页面
    headers.set("Cache-Control", "public, max-age=3600");
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "no-referrer");
    headers.set("Cross-Origin-Resource-Policy", "cross-origin");
    // 不设 Content-Disposition: attachment，避免图片变成"下载"。inline 仅用于提示
    headers.set("Content-Disposition", "inline");
    return new Response(object.body, { headers });
  }

  // ---------- 1.5 外部只读取图设置（仅超级管理员）：开关 + 密钥管理 ----------
  // 界面入口在「超管权限 → 前台访问设置」，接口同样只放超管，避免普通管理员绕过界面直接调用
  if (path === "agent-read" && (method === "GET" || method === "POST")) {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isSuperRole(role)) return json({ error: "仅超级管理员可操作" }, 403, CORS);
    if (!env.SUPABASE_SERVICE_ROLE_KEY) return json({ error: "服务端未配置读写权限" }, 500, CORS);

    const base = env.SUPABASE_URL + "/rest/v1/site_secrets";
    const srv = {
      apikey: env.SUPABASE_SERVICE_ROLE_KEY,
      Authorization: "Bearer " + env.SUPABASE_SERVICE_ROLE_KEY,
      "Content-Type": "application/json",
    };

    // 读取当前设置（强制刷新，拿最新密钥）
    if (method === "GET") {
      const cur = await getAgentRead(env, true);
      return json({ ok: true, on: cur.on, key: cur.key }, 200, CORS);
    }

    // 修改：开关、重置密钥
    const body = await request.json().catch(function () { return {}; });
    const cur = await getAgentRead(env, true);
    const patch = { updated_at: new Date().toISOString() };
    if (typeof body.on === "boolean") patch.agent_read = body.on;
    if (body.reset === true) patch.agent_read_key = genReadKey();

    // 开启时若还没有密钥，自动补一个
    const willBeOn = typeof body.on === "boolean" ? body.on : cur.on;
    const willHaveKey = patch.agent_read_key || cur.key;
    if (willBeOn && !willHaveKey) patch.agent_read_key = genReadKey();

    const res2 = await fetch(base + "?id=eq.1", {
      method: "PATCH",
      headers: Object.assign({ Prefer: "return=representation" }, srv),
      body: JSON.stringify(patch),
    });
    if (!res2.ok) return json({ error: "保存失败" }, 502, CORS);
    const arr2 = await res2.json().catch(function () { return []; });
    const r2 = Array.isArray(arr2) && arr2[0];

    // 清掉 60 秒缓存，开关切换后下一次读图立刻按新状态判定
    _arVal = null;
    _arAt = 0;

    return json({
      ok: true,
      on: !!(r2 && r2.agent_read),
      key: (r2 && r2.agent_read_key) || "",
    }, 200, CORS);
  }

  // ---------- 2. POST 上传：需要管理员 ----------
  if (method === "POST" && path === "upload") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "visual"))) return json({ error: "未授权该专区" }, 403, CORS);

    const form = await request.formData();
    const file = form.get("file");
    const category = (form.get("category") || "").trim();
    if (!file || !category) return json({ error: "缺少文件或分类" }, 400, CORS);
    // 类目授权校验：管理员只能上传其授权（视觉专区）类目的图片
    if (!(await canManageZoneCat(userId, role, token, env, "visual", category))) {
      return json({ error: "未授权该分类" }, 403, CORS);
    }

    // 唯一文件名，防覆盖
    const cleanName = file.name.replace(/[^\w.\-]/g, "_");
    const stamp = Date.now() + "_" + Math.floor(Math.random() * 1e4);
    // 中文类目统一明文存储（与取图时 decodeURIComponent 还原后的中文路径完全一致），避免 404
    const key = `images/${category}/${stamp}_${cleanName}`;

    await env.IMAGES.put(key, file.stream(), {
      httpMetadata: { contentType: file.type || "application/octet-stream" },
    });
    return json({ ok: true, path: key }, 200, CORS);
  }

  // ---------- 3. DELETE 删除：需要管理员 ----------
  if (method === "DELETE" && path.startsWith("images/")) {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    const rawPath = url.pathname.replace(/^\//, "");
    // 先删解码后路径，若不存在再删原始编码路径，兼容新旧存储
    await env.IMAGES.delete(path).catch(() => {});
    if (rawPath !== path) await env.IMAGES.delete(rawPath).catch(() => {});
    return json({ ok: true }, 200, CORS);
  }

  // ---------- 4. 趋势专区（趋势文件存 R2，由本 Worker 受控代理，不暴露直链） ----------

  // 4.1 POST /trend/upload 上传趋势文件（管理员）→ 返回 R2 path
  if (method === "POST" && path === "trend/upload") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "trend"))) return json({ error: "未授权该专区" }, 403, CORS);

    const form = await request.formData();
    const file = form.get("file");
    if (!file) return json({ error: "缺少文件" }, 400, CORS);
    // 仅允许 pdf（可放宽为常见文档，但预览窗口为 pdf）
    const isPdf = /pdf/i.test(file.type) || /\.pdf$/i.test(file.name || "");
    if (!isPdf) return json({ error: "暂仅支持 PDF" }, 400, CORS);

    // 唯一文件名：英文/数字/下划线/点，避免中文 URL 编码问题
    const cleanName = (file.name || "trend.pdf").replace(/[^\w.\-]/g, "_");
    const stamp = Date.now() + "_" + Math.floor(Math.random() * 1e4);
    const key = "trends/" + stamp + "_" + cleanName;
    await env.IMAGES.put(key, file.stream(), {
      httpMetadata: { contentType: "application/pdf" },
    });

    // 可选封面图：存 trends_covers/ 目录，同样受控代理，不暴露直链
    let coverPath = "";
    const coverFile = form.get("cover");
    if (coverFile && coverFile.size > 0) {
      if (!/^image\//i.test(coverFile.type || "")) return json({ error: "封面仅支持图片" }, 400, CORS);
      const cName = (coverFile.name || "cover.jpg").replace(/[^\w.\-]/g, "_");
      coverPath = "trends_covers/" + stamp + "_" + cName;
      await env.IMAGES.put(coverPath, coverFile.stream(), {
        httpMetadata: { contentType: coverFile.type || "image/jpeg" },
      });
    }
    return json({ ok: true, path: key, cover: coverPath }, 200, CORS);
  }

  // 4.1b POST /trend/uploadCover 单独上传/替换趋势封面（管理员）→ 返回新 R2 cover 路径
  if (method === "POST" && path === "trend/uploadCover") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "trend"))) return json({ error: "未授权该专区" }, 403, CORS);
    const form = await request.formData();
    const coverFile = form.get("cover");
    if (!coverFile || coverFile.size <= 0) return json({ error: "缺少封面" }, 400, CORS);
    if (!/^image\//i.test(coverFile.type || "")) return json({ error: "封面仅支持图片" }, 400, CORS);
    const cName = (coverFile.name || "cover.jpg").replace(/[^\w.\-]/g, "_");
    const stamp = Date.now() + "_" + Math.floor(Math.random() * 1e4);
    const coverPath = "trends_covers/" + stamp + "_" + cName;
    await env.IMAGES.put(coverPath, coverFile.stream(), {
      httpMetadata: { contentType: coverFile.type || "image/jpeg" },
    });
    return json({ ok: true, cover: coverPath }, 200, CORS);
  }

  // 4.2 GET /trend/preview?path=trends/xxx   受控预览：必须登录，返回 PDF 内联，防下载/防另存
  if (method === "GET" && path === "trend/preview") {
    // 趋势专区始终需登录可见（不受公开浏览开关影响）
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const p = url.searchParams.get("path") || "";
    if (!p.startsWith("trends/")) return json({ error: "参数错误" }, 400, CORS);
    const object = await env.IMAGES.get(p);
    if (!object) return json({ error: "文件不存在" }, 404, CORS);
    const headers = new Headers(CORS);
    headers.set("Content-Type", "application/pdf");
    // 内联打开，而非附件下载；明确禁止浏览器把它当可下载附件
    headers.set("Content-Disposition", "inline");
    // 防下载/防另存：禁止嗅探、禁止被外站直链引用、不缓存原始字节（避免留痕便于另存）
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "no-referrer");
    headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
    headers.set("Pragma", "no-cache");
    headers.set("Cross-Origin-Resource-Policy", "cross-origin");
    return new Response(object.body, { headers });
  }

  // 4.3 GET /trend/cover?path=trends_covers/xxx  受控封面图：必须登录，内联展示，防下载
  if (method === "GET" && path === "trend/cover") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const p = url.searchParams.get("path") || "";
    if (!p.startsWith("trends_covers/")) return json({ error: "参数错误" }, 400, CORS);
    const object = await env.IMAGES.get(p);
    if (!object) return json({ error: "文件不存在" }, 404, CORS);
    const headers = new Headers(CORS);
    headers.set("Content-Type", object.httpMetadata?.contentType || "image/jpeg");
    headers.set("Content-Disposition", "inline");
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "no-referrer");
    headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
    headers.set("Pragma", "no-cache");
    headers.set("Cross-Origin-Resource-Policy", "cross-origin");
    return new Response(object.body, { headers });
  }

  // 4.4 DELETE /trend/delete?path=trends/xxx&cover=trends_covers/xxx  删除趋势文件（管理员）
  if (method === "DELETE" && path === "trend/delete") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "trend"))) return json({ error: "未授权该专区" }, 403, CORS);
    const p = url.searchParams.get("path") || "";
    if (!p.startsWith("trends/")) return json({ error: "参数错误" }, 400, CORS);
    await env.IMAGES.delete(p).catch(() => {});
    const coverParam = url.searchParams.get("cover") || "";
    if (coverParam.startsWith("trends_covers/")) await env.IMAGES.delete(coverParam).catch(() => {});
    return json({ ok: true }, 200, CORS);
  }

  // ---------- 5. 公告专区（公告图片存 R2，受控代理，不暴露直链） ----------
  // 5.1 POST /notice/uploadimg 上传公告图片（管理员）→ 返回 notices/ 路径
  if (method === "POST" && path === "notice/uploadimg") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "notice"))) return json({ error: "未授权该专区" }, 403, CORS);

    const form = await request.formData();
    const file = form.get("file");
    if (!file) return json({ error: "缺少图片" }, 400, CORS);
    if (!/^image\//i.test(file.type || "") && !/\.(jpe?g|png|webp)$/i.test(file.name || "")) {
      return json({ error: "仅支持图片" }, 400, CORS);
    }
    const cleanName = (file.name || "img").replace(/[^\w.\-]/g, "_");
    const stamp = Date.now() + "_" + Math.floor(Math.random() * 1e4);
    const key = "notices/" + stamp + "_" + cleanName;
    await env.IMAGES.put(key, file.stream(), {
      httpMetadata: { contentType: file.type || "image/jpeg" },
    });
    return json({ ok: true, path: key }, 200, CORS);
  }

  // 5.2 GET /notice/img?path=notices/xxx  受控公告图片：必须登录，内联展示，防下载
  if (method === "GET" && path === "notice/img") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const p = url.searchParams.get("path") || "";
    if (!p.startsWith("notices/")) return json({ error: "参数错误" }, 400, CORS);
    const object = await env.IMAGES.get(p);
    if (!object) return json({ error: "文件不存在" }, 404, CORS);
    const headers = new Headers(CORS);
    headers.set("Content-Type", object.httpMetadata?.contentType || "image/jpeg");
    headers.set("Content-Disposition", "inline");
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "no-referrer");
    headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
    headers.set("Pragma", "no-cache");
    headers.set("Cross-Origin-Resource-Policy", "cross-origin");
    return new Response(object.body, { headers });
  }

  // 5.3 POST /marketing/uploadimg 上传营销日历图片（管理员）→ 返回 marketing/ 路径
  if (method === "POST" && path === "marketing/uploadimg") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isSuperRole(role)) return json({ error: "仅超级管理员可操作" }, 403, CORS);

    const form = await request.formData();
    const file = form.get("file");
    if (!file) return json({ error: "缺少图片" }, 400, CORS);
    if (!/^image\//i.test(file.type || "") && !/\.(jpe?g|png|webp)$/i.test(file.name || "")) {
      return json({ error: "仅支持图片" }, 400, CORS);
    }
    const cleanName = (file.name || "img").replace(/[^\w.\-]/g, "_");
    const stamp = Date.now() + "_" + Math.floor(Math.random() * 1e4);
    const key = "marketing/" + stamp + "_" + cleanName;
    await env.IMAGES.put(key, file.stream(), {
      httpMetadata: { contentType: file.type || "image/jpeg" },
    });
    return json({ ok: true, path: key }, 200, CORS);
  }

  // 5.4 GET /marketing/img?path=marketing/xxx  受控营销日历图片：必须登录，内联展示，防下载
  if (method === "GET" && path === "marketing/img") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const p = url.searchParams.get("path") || "";
    if (!p.startsWith("marketing/")) return json({ error: "参数错误" }, 400, CORS);
    const object = await env.IMAGES.get(p);
    if (!object) return json({ error: "文件不存在" }, 404, CORS);
    const headers = new Headers(CORS);
    headers.set("Content-Type", object.httpMetadata?.contentType || "image/jpeg");
    headers.set("Content-Disposition", "inline");
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "no-referrer");
    headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
    headers.set("Pragma", "no-cache");
    headers.set("Cross-Origin-Resource-Policy", "cross-origin");
    return new Response(object.body, { headers });
  }

  // ---------- 6. 招品回品专区（招品图片存 R2，受控代理，不暴露直链） ----------
  // 6.1 POST /recruit/upload 上传招品图片（管理员）→ 返回 recruits/ 路径
  if (method === "POST" && path === "recruit/upload") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "recruit"))) return json({ error: "未授权该专区" }, 403, CORS);

    const form = await request.formData();
    const file = form.get("file");
    if (!file) return json({ error: "缺少图片" }, 400, CORS);
    if (!/^image\//i.test(file.type || "") && !/\.(jpe?g|png|webp)$/i.test(file.name || "")) {
      return json({ error: "仅支持图片" }, 400, CORS);
    }
    const cleanName = (file.name || "img").replace(/[^\w.\-]/g, "_");
    const stamp = Date.now() + "_" + Math.floor(Math.random() * 1e4);
    const key = "recruits/" + stamp + "_" + cleanName;
    await env.IMAGES.put(key, file.stream(), {
      httpMetadata: { contentType: file.type || "image/jpeg" },
    });
    return json({ ok: true, path: key }, 200, CORS);
  }

  // 6.2 GET /recruit/img?path=recruits/xxx  受控招品图片：登录可见，内联展示，防下载
  if (method === "GET" && path === "recruit/img") {
    // 方案A：未登录预览放行（分享类目缩略图），原图受限流+审计兜底；不回退拦截
    const p = (url.searchParams.get("path") || "").trim();
    // 兼容历史/不同前缀的图片路径：只要不包含目录穿越且非空即放行，避免误拦 400
    if (!p || p.includes("..") || p.startsWith("/")) return json({ error: "参数错误" }, 400, CORS);
    const object = await env.IMAGES.get(p);
    if (!object) return json({ error: "文件不存在" }, 404, CORS);
    const headers = new Headers(CORS);
    headers.set("Content-Type", object.httpMetadata?.contentType || "image/jpeg");
    headers.set("Content-Disposition", "inline");
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "no-referrer");
    headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
    headers.set("Pragma", "no-cache");
    headers.set("Cross-Origin-Resource-Policy", "cross-origin");
    return new Response(object.body, { headers });
  }

  // 6.3 DELETE /recruit/delete?path=recruits/xxx  删除招品图片（管理员）
  if (method === "DELETE" && path === "recruit/delete") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "recruit"))) return json({ error: "未授权该专区" }, 403, CORS);
    const p = url.searchParams.get("path") || "";
    if (!p.startsWith("recruits/")) return json({ error: "参数错误" }, 400, CORS);
    await env.IMAGES.delete(p).catch(() => {});
    return json({ ok: true }, 200, CORS);
  }

  // ---------- 6. BESTSELLER回品专区（BESTSELLER图片存 R2，受控代理，不暴露直链） ----------
  // 6.1 POST /bestseller/upload 上传BESTSELLER图片（管理员）→ 返回 bestsellers/ 路径
  if (method === "POST" && path === "bestseller/upload") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "bestseller"))) return json({ error: "未授权该专区" }, 403, CORS);

    const form = await request.formData();
    const file = form.get("file");
    if (!file) return json({ error: "缺少图片" }, 400, CORS);
    if (!/^image\//i.test(file.type || "") && !/\.(jpe?g|png|webp)$/i.test(file.name || "")) {
      return json({ error: "仅支持图片" }, 400, CORS);
    }
    const cleanName = (file.name || "img").replace(/[^\w.\-]/g, "_");
    const stamp = Date.now() + "_" + Math.floor(Math.random() * 1e4);
    const key = "bestsellers/" + stamp + "_" + cleanName;
    await env.IMAGES.put(key, file.stream(), {
      httpMetadata: { contentType: file.type || "image/jpeg" },
    });
    return json({ ok: true, path: key }, 200, CORS);
  }

  // 6.2 GET /bestseller/img?path=bestsellers/xxx  受控BESTSELLER图片：登录可见，内联展示，防下载
  if (method === "GET" && path === "bestseller/img") {
    // 方案A：未登录预览放行（分享类目缩略图）
    const p = (url.searchParams.get("path") || "").trim();
    // 兼容历史/不同前缀的图片路径：只要不包含目录穿越且非空即放行，避免误拦 400
    if (!p || p.includes("..") || p.startsWith("/")) return json({ error: "参数错误" }, 400, CORS);
    const object = await env.IMAGES.get(p);
    if (!object) return json({ error: "文件不存在" }, 404, CORS);
    const headers = new Headers(CORS);
    headers.set("Content-Type", object.httpMetadata?.contentType || "image/jpeg");
    headers.set("Content-Disposition", "inline");
    headers.set("X-Content-Type-Options", "nosniff");
    headers.set("Referrer-Policy", "no-referrer");
    headers.set("Cache-Control", "no-store, no-cache, must-revalidate");
    headers.set("Pragma", "no-cache");
    headers.set("Cross-Origin-Resource-Policy", "cross-origin");
    return new Response(object.body, { headers });
  }

  // 6.3 DELETE /bestseller/delete?path=bestsellers/xxx  删除BESTSELLER图片（管理员）
  if (method === "DELETE" && path === "bestseller/delete") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    if (!(await canManageZone(userId, role, token, env, "bestseller"))) return json({ error: "未授权该专区" }, 403, CORS);
    const p = url.searchParams.get("path") || "";
    if (!p.startsWith("bestsellers/")) return json({ error: "参数错误" }, 400, CORS);
    await env.IMAGES.delete(p).catch(() => {});
    return json({ ok: true }, 200, CORS);
  }

  // 7. 存量图片压缩池：列出存储全部图片（key + size），仅管理员
  if (method === "GET" && path === "admin/list-imgs") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    const items = [];
    let cursor;
    do {
      const page = await env.IMAGES.list({ cursor, limit: 1000 });
      for (const o of (page.objects || [])) {
        // 只保留视觉专区图片（key 以 images/ 开头），排除趋势/招品/回品等其它专区
        if (o.key && o.key.startsWith("images/")) items.push({ key: o.key, size: o.size });
      }
      cursor = page.truncated ? page.cursor : undefined;
    } while (cursor);
    return json({ ok: true, items }, 200, CORS);
  }

  // 8. 存量图片压缩池：按原路径覆盖写回压缩后的图（转 WebP），仅管理员
  if (method === "POST" && path === "admin/overwrite") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isAdminRole(role)) return json({ error: "无管理员权限" }, 403, CORS);
    const p = url.searchParams.get("path") || "";
    if (!p) return json({ error: "参数错误" }, 400, CORS);
    const form = await request.formData().catch(() => null);
    const file = form ? form.get("file") : null;
    if (!file) return json({ error: "缺少文件" }, 400, CORS);
    await env.IMAGES.put(p, file.stream(), {
      httpMetadata: { contentType: file.type || "image/webp" },
    });
    return json({ ok: true }, 200, CORS);
  }

  // 9. 超管用户管理——创建 Auth 用户（邮箱 + 密码），仅超级管理员
  if (method === "POST" && path === "admin/user/create") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isSuperRole(role)) return json({ error: "仅超级管理员可操作" }, 403, CORS);
    if (!env.SUPABASE_SERVICE_ROLE_KEY) return json({ error: "服务端未配置 service_role" }, 500, CORS);
    const body = await request.json().catch(() => ({}));
    const email = (body.email || "").trim();
    const password = (body.password || "").trim();
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "邮箱格式不正确" }, 400, CORS);
    if (!password || password.length < 6) return json({ error: "密码至少 6 位" }, 400, CORS);
    try {
      const u = await adminCreateAuthUser(env, email, password);
      return json({ ok: true, user: u }, 200, CORS);
    } catch (e) {
      return json({ error: e.message || "创建用户失败" }, 400, CORS);
    }
  }
  // 9.1 超管用户管理——删除 Auth 用户（级联清理 profiles），仅超级管理员
  if (method === "DELETE" && path === "admin/user/delete") {
    if (!userId) return json({ error: "未登录" }, 401, CORS);
    const role = await getRole(userId, token, env);
    if (!isSuperRole(role)) return json({ error: "仅超级管理员可操作" }, 403, CORS);
    if (!env.SUPABASE_SERVICE_ROLE_KEY) return json({ error: "服务端未配置 service_role" }, 500, CORS);
    const uid = (url.searchParams.get("uid") || "").trim();
    if (!uid) return json({ error: "缺少用户 ID" }, 400, CORS);
    // 先删 profiles（防外键/触发器报错），再删 auth 用户；均忽略单步失败
    await fetch(env.SUPABASE_URL + "/rest/v1/profiles?user_id=eq." + encodeURIComponent(uid), {
      method: "DELETE",
      headers: {
        apikey: env.SUPABASE_SERVICE_ROLE_KEY,
        Authorization: "Bearer " + env.SUPABASE_SERVICE_ROLE_KEY,
      },
    }).catch(() => {});
    try {
      await adminDeleteAuthUser(env, uid);
      return json({ ok: true }, 200, CORS);
    } catch (e) {
      return json({ error: e.message || "删除用户失败" }, 400, CORS);
    }
  }

  return json({ error: "未知请求" }, 404, CORS);
}

function json(data, status, cors) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...cors },
  });
}

export default {
  async fetch(request, env) {
    try {
      return await handleRequest(request, env);
    } catch (e) {
      return json({ error: "服务异常" }, 500, CORS);
    }
  },
};